# fox-ler.github.io

This repository hosts the website for **fox-ler** at [https://fox-ler.github.io](https://fox-ler.github.io).

## How to Publish

1. Go to [https://github.com/new](https://github.com/new) and create a new repository named **fox-ler.github.io** (must match your GitHub username exactly).  
2. Upload all the files from this ZIP (including `.nojekyll` and `index.html`) into the new repository.  
3. Commit and push (or drag-drop via GitHub web UI).  
4. Wait 1–2 minutes, then visit:  
   👉 [https://fox-ler.github.io](https://fox-ler.github.io)

Your site should be live!

---
Minimal setup — no build step, no Jekyll. Just static HTML/CSS/JS served directly by GitHub Pages.
